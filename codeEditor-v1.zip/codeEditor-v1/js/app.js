const Editor = () => document.getElementById('codeEditor');

window.addEventListener('DOMContentLoaded', function() {
  "use strict";
  Editor().onkeydown = function (e) {
	var keyCode = e.keyCode || e.which;

	var total =  Number(this.value.length);
    var start = this.selectionStart;
    var end = this.selectionEnd;

	if (keyCode == 9) {
		e.preventDefault();

    	Editor().value = Editor().value.substring(0, start) + "\t" + Editor().value.substring(end);
    	return this.selectionStart = this.selectionEnd = start + 1;
    } 

    return null;
  };

});
