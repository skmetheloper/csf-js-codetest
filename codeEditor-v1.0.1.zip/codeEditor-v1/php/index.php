<?php
	 header("Access-Control-Allow-Origin: *");
	 header("Content-Type: text/json");
	 
	$reqMethod = $_SERVER["REQUEST_METHOD"];

	if ($reqMethod == "GET") {
		http_response_code(201);
		echo '{ "scheme": "REST-API", "method": "GET" }';
	} else {
		http_response_code(203);
		echo '{ "scheme": "REST-API", "method": "POST", "value": "' . file_get_contents("php://input") . '" }';
	}