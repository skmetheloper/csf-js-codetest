const CeRs = {
  response: [],
  responseText: [],
  status: []
}

const reqApi = {
  localhost: (m) => {
    var method = "GET";
    if (m) {
      method = "POST";
    }

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
       try {
        CeRs.response.push(JSON.parse(this.response));
       }catch (error) {
        CeRs.response.push(error.message);
       } finally {
         CeRs.responseText.push(this.response);
         CeRs.status.push(this.status);  
         Editor(this.response);
         Log();
       }
      }
    }
    xhttp.open(method, "//localhost:8080");
    xhttp.send((m||""));

    console.debug({ token: CeRs.response.length + 1 });
    return CeRs.response.length + 1;
  }
}

window.onload = () => {

    Log(reqApi.localhost({platform: navigator.platform, browser: [navigator.appName, navigator.appVersion]}), "Index has queried");


}