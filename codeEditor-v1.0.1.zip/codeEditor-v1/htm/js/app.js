const Editor = (value) => {
  if (value) {
    return document.getElementById('codeEditor').value = value;
  }
  return document.getElementById('codeEditor');
}, Log = (func, text) => {
  try {
    func();
    document.getElementById("preload-status").innerText = text;
    return true;
  }catch (err1) {

    try {
      text = func;
      if (text) {
        document.getElementById("preload-status").innerText = text;
      } else {
        document.getElementById("preload-status").innerText = "Error1::" + err1.message;
      }
    } catch (err2) {
      document.getElementById("preload-status").innerText = "Error2::" + err2.message;
    }
    
  return false;
  }
};

window.addEventListener('DOMContentLoaded', function() {
  "use strict";
  Editor().onkeydown = function (e) {
	var keyCode = e.keyCode || e.which;

	var total =  Number(this.value.length);
    var start = this.selectionStart;
    var end = this.selectionEnd;

	if (keyCode == 9) {
		e.preventDefault();

    	Editor().value = Editor().value.substring(0, start) + "\t" + Editor().value.substring(end);
    	return this.selectionStart = this.selectionEnd = start + 1;
    } 

    return null;
  };

});

var clearPreload = () => {
    var loader = document.getElementById('loader');
    setTimeout(() => {
    loader.classList.add('fadeOut');
      setTimeout(()=>{
      loader.remove();
    }, 800)
  }, 300);
};